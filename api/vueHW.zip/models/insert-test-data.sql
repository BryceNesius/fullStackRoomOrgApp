INSERT INTO account (first_name, last_name, email, password)
VALUES ('Fred', 'Ziffle', 'fred@ziffle.com', 'SuperSecret1');
INSERT INTO account (first_name, last_name, email, password)
VALUES ('Zelda', 'Ziffle', 'zelda@ziffle.com', 'SuperSecret2');
